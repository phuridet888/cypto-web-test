import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/crypto_controller.dart';
import '../controllers/theme_controller.dart';
import 'detail_page.dart';

class HomePage extends StatelessWidget {
  final CryptoController controller = Get.put(CryptoController());
  final ThemeController themeController = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Crypto Tracker"),
        actions: [
          IconButton(
            icon: Icon(Icons.brightness_6),
            onPressed: () => themeController.toggleTheme(),
          )
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        }
        return ListView.builder(
          itemCount: controller.coins.length,
          itemBuilder: (context, index) {
            final coin = controller.coins[index];
            return ListTile(
              leading: Image.network(coin.image, width: 32, height: 32),
              title: Text(coin.name),
              subtitle: Text(coin.symbol.toUpperCase()),
              trailing: Text("\$${coin.currentPrice.toStringAsFixed(2)}"),
              onTap: () {
                Get.to(() => DetailPage(coin: coin));
              },
            );
          },
        );
      }),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/crypto.dart';

class DetailPage extends StatelessWidget {
  final Crypto coin;

  const DetailPage({required this.coin});

  List<FlSpot> getFakeData() {
    // You can replace this with real data if available
    return List.generate(20, (index) {
      return FlSpot(index.toDouble(), (coin.currentPrice * (0.9 + index / 100)).toDouble());
    });
  }

  @override
  Widget build(BuildContext context) {
    final spots = getFakeData();

    return Scaffold(
      appBar: AppBar(
        title: Text(coin.name),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.network(coin.image, width: 64, height: 64),
            SizedBox(height: 16),
            Text(
              coin.name,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            Text(coin.symbol.toUpperCase(), style: TextStyle(fontSize: 18)),
            Text("\$${coin.currentPrice.toStringAsFixed(2)}", style: TextStyle(fontSize: 20)),
            SizedBox(height: 32),
            Expanded(
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(show: true),
                  borderData: FlBorderData(show: true),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: true),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    rightTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    topTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: spots,
                      isCurved: true,
                      color: Theme.of(context).colorScheme.primary,
                      barWidth: 3,
                      belowBarData: BarAreaData(show: false),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'dart:convert';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import '../models/crypto.dart';

class CryptoController extends GetxController {
  var coins = <Crypto>[].obs;
  var isLoading = true.obs;

  @override
  void onInit() {
    fetchCoins();
    super.onInit();
  }

  void fetchCoins() async {
    try {
      isLoading(true);
      var url = Uri.parse(
          'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=bitcoin,ethereum,dogecoin,binancecoin,ripple,solana');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        var result = json.decode(response.body) as List;
        coins.value = result.map((e) => Crypto.fromJson(e)).toList();
      }
    } finally {
      isLoading(false);
    }
  }
}
